
import { useState } from "react";

const timeline = [
  { year: 1947, seconds: 420, reason: "Start of the Cold War." },
  { year: 1991, seconds: 1020, reason: "End of the Cold War." },
  { year: 2018, seconds: 120, reason: "Global political instability and climate risks." },
  { year: 2020, seconds: 100, reason: "Nuclear tensions, climate change, disinformation." },
  { year: 2023, seconds: 90, reason: "War in Ukraine, AI risks, and climate crisis." },
  { year: 2024, seconds: 90, reason: "Ongoing global conflicts and lack of global cooperation." }
];

export default function DoomsdayClock() {
  const [index, setIndex] = useState(timeline.length - 1);
  const current = timeline[index];

  const getProgress = () => {
    return ((100 - Math.min(current.seconds, 100)) / 100) * 100;
  };

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#111', color: '#fff', padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1 style={{ fontSize: '2rem', textAlign: 'center' }}>Doomsday Clock</h1>
      <div style={{ maxWidth: '400px', margin: '2rem auto', padding: '1rem', backgroundColor: '#222', borderRadius: '8px' }}>
        <p><strong>Time to Midnight:</strong> {current.seconds} seconds</p>
        <progress value={getProgress()} max={100} style={{ width: '100%' }}></progress>
        <p><strong>Year:</strong> {current.year}</p>
        <p><strong>Reason:</strong> {current.reason}</p>
      </div>
      <div style={{ maxWidth: '400px', margin: '0 auto' }}>
        <input type="range" min="0" max={timeline.length - 1} value={index} onChange={(e) => setIndex(Number(e.target.value))} />
        <div style={{ textAlign: 'center', marginTop: '0.5rem' }}>Use the slider to view changes over time</div>
      </div>
    </div>
  );
}
