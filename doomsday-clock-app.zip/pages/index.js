
import DoomsdayClock from "@/components/ui/DoomsdayClock";

export default function Home() {
  return <DoomsdayClock />;
}
